import Cal from "./calendar";
import img from '../../../assets/images/img.jpg'
import img2 from '../../../assets/images/download.jpeg'

export default function Right() {
    return (
        <>
            <div className="right">
                
                <h1 className="heading-post" style={{ color: "black", textAlign: "center", margin: "1rem 0"}}>Event Calendar</h1>
                
                <Cal img={img} p={"12, january 2024"}/>

                <Cal img={img2} p={"12, january 2024"}/>
                
            </div>

        </>
    )
}