

export default function Cal({img, p}){
    return(
        <div>
            <img className='img-cal' src={img} alt="img" />
            <p style={{textAlign: "center", margin: "0.5rem 0"}}>{p}</p>
        </div>
    )
}