import * as React from 'react';
import Backdrop from '@mui/material/Backdrop';
import Box from '@mui/material/Box';
import Modal from '@mui/material/Modal';
import Fade from '@mui/material/Fade';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import { Input } from 'antd';
import Profile from '../../../assets/images/profile.png'
import App from './form';

const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  boxShadow: 24,
  borderRadius: "4px",
  padding: '10px 0'
};

export default function TransitionsModal() {
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  let place_holder = `What's on your mind, ${'Tanseer-Basit'}`
  return (
    <div style={{margin: "3rem 0 0 0"}}>
      <div  onClick={handleOpen}>
        <div className='center-modal'>
          <div className='center-modal-sub'>
            <img style={{margin: "1.8rem 0"}} className='profile-img' src={Profile} alt="Profile" />
            <Input style={{ backgroundColor: "#10171E", margin: "1.5rem 1rem" }} className='field' placeholder={place_holder} disabled />;
          </div>
        </div>
      </div>
      <Modal
        aria-labelledby="transition-modal-title"
        aria-describedby="transition-modal-description"
        open={open}
        onClose={handleClose}
        closeAfterTransition
      >
        <Fade in={open}>
          <Box sx={style}>
            <div className='create-post'>
              <h1>Create Post</h1>
              <hr />
              <div style={{display: "flex", padding: "1rem 0"}}>
                <img style={{margin: "0 0.5rem"}} className='profile-img' src={Profile} alt="profile" />
                <p className='text-style' style={{margin: "0.5rem 0"}}>Tanseer-Basit</p>
              </div>
              <App handleClose={handleClose}/>
            </div>
          </Box>
        </Fade>
      </Modal>
    </div>
  );
}