import React from 'react';
import { Button, Form, Input } from 'antd';
import { UploadOutlined } from '@ant-design/icons';
const { TextArea } = Input;


export default function App({ handleClose }) {
    const onFinish = (values) => {
        if(values.text){
            console.log('Success:', values);
            handleClose();
        }
        else if(values.file){
            console.log('Success:', values);
            handleClose();
        }
        
    };
    const onFinishFailed = (errorInfo) => {
        console.log('Failed:', errorInfo);
    };
    let place_holder = `What's on your mind, ${'Tanseer-Basit'}`
    return(
    <Form
        name="basic"
        initialValues={{
            remember: true,
        }}
        onFinish={onFinish}
        onFinishFailed={onFinishFailed}
        autoComplete="off"
    >
        <Form.Item
            name="text"
            rules={[
                {
                    message: '',
                },
            ]}
        >
            <TextArea
                maxLength={100}
                style={{
                    height: 120,
                    width: 400,
                    resize: 'none',
                    border: "none"
                }} placeholder={place_holder}/>
        </Form.Item>
        <Form.Item
        name="file"
        >
            <Input type='file' accept="image/x-png, image/gif, image/jpeg, video/mp4"/>
        </Form.Item>
            <button style={{width: "380px", padding: "0.5rem", borderRadius: "8px", backgroundColor: "#0866ff", color: "#fff", fontStyle: "Inter", fontSize: "16px", fontWeight: "600"}}>
                Post
            </button>
    </Form>
)};