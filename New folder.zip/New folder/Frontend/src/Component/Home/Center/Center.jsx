
import TransitionsModal from "./Modal"
import Post from "./Post/post"
export default function Center() {
    return (
        <div>
            <TransitionsModal />
            <div style={{margin: "3rem 0 0 0"}}>
                <Post />
            </div>
            <div style={{margin: "3rem 0 0 0"}}>
                <Post />
            </div>
            <div style={{margin: "3rem 0 0 0"}}>
                <Post />
            </div>
        </div>
    )
}