
import profile from '../../../../assets/images/profile.png'
import post from '../../../../assets/images/post.png'
import BookmarkBorderOutlinedIcon from '@mui/icons-material/BookmarkBorderOutlined';
import FavoriteBorderOutlinedIcon from '@mui/icons-material/FavoriteBorderOutlined';
import ShareOutlinedIcon from '@mui/icons-material/ShareOutlined';
import MapsUgcOutlinedIcon from '@mui/icons-material/MapsUgcOutlined';
import Sec from './firstSubSec';

import Menu from './menu'
import { Button } from 'antd'
import { useState } from 'react';
export default function Post({video, caption}) {
    const [share, setShare] = useState(false);
    const [like, setLike] = useState(false);

    const likeBtn = () => {
        if (like) {
            setLike(false)
        } else {
            setLike(true)
        }
    }

    const saveBtn = () => {
        if (share) {
            setShare(false)
        } else {
            setShare(true)
        }
    }
    return (
        <div>
            <div>
                <div className="post">
                    <div className="post-sec1">
                        <Sec />
                        <div>
                            <Menu />
                        </div>
                    </div>
                    {
                        caption?
                        <p className='caption'>{caption}</p>:null
                    } 
                    {
                        video?
                        <video className='video' src={video} alt="video" controls/>
                        :
                        <img className='post-main-img' src={post} alt="post" />
                    }
                    

                    <div className='post-sec1'>
                        <div style={{ display: "flex" }}>
                            <p className='heading-post' style={{ color: "#A1A1A1", marginRight: "1rem" }}>216 Likes</p>
                            <p className='heading-post' style={{ color: "#A1A1A1" }}>43 Comments</p>
                        </div>
                        <div>
                            <p className='heading-post' style={{ color: "#A1A1A1" }}>100 Shares</p>
                        </div>
                    </div>

                    <hr style={{ color: "#324151", margin: "0rem 24px" }} />

                    <div className='post-sec2'>
                        <div>
                            <button onClick={likeBtn} style={like ? { color: "red" } : { color: "" }}><FavoriteBorderOutlinedIcon style={{ width: "20px" }} /> Like</button>
                            <button style={{ margin: "0 1rem" }}><MapsUgcOutlinedIcon style={{ width: "20px" }} /> Comment</button>
                            <button><ShareOutlinedIcon style={{ width: "20px" }} /> Share</button>
                        </div>
                        <div>
                            <button onClick={saveBtn} style={share ? { color: "#335DD2" } : { color: "" }}><BookmarkBorderOutlinedIcon style={{ width: "20px" }} /></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}