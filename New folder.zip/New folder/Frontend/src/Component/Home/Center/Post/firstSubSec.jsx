
import profile from '../../../../assets/images/profile.png'
export default function Sec() {
    return (
        <div style={{ display: "flex" }}>
            <img className='post-profile-img' src={profile} alt="profile" />
            <div>
                <h1 className='heading-post'>Tanseer-Basit</h1>
                <p className='post-time'>@tanseerBasit • 2 hours ago</p>
            </div>
        </div>
    )
}