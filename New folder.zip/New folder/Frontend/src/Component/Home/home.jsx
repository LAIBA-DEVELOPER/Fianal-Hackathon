import Center from "./Center/Center"
import Right from "./Right/right"
import Navbar1 from "../Navbar.jsx/navbar"
export default function Home(){
    return(
        <div>
            <Navbar1/>
            
        <div className="home">
            <Center/>
            <Right/>
        </div>
        </div>
    )
}