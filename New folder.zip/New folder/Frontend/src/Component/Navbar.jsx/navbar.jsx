import Container from 'react-bootstrap/Container';
import Navbar from 'react-bootstrap/Navbar';
import { useNavigate } from 'react-router-dom';

function Navbar1() {
  const navigate = useNavigate();
  const signOUt = () =>{
    localStorage.removeItem("Admin_ID")
    navigate('/')
  } 
  return (
    <Navbar expand="lg" style={{backgroundColor: "black", color: "white"}}>
      <Container>
        <Navbar.Brand style={{color: "#fff"}} href="#">Ecohub : GreenBurg</Navbar.Brand>
      </Container>
      <button onClick={signOUt} style={{widh: "20px", padding: "0 12px", color: "#fff"}}>Sign OUt</button>
      {/* <Container>
        <Navbar.Brand style={{color: "#fff"}} href="#">Ecohub : GreenBurg</Navbar.Brand>
      </Container> */}
    </Navbar>
  );
}

export default Navbar1;