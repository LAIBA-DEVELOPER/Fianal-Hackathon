import Log from "./Login"

export default function Login(){
  return(
    <Log heading={"Login"} axiosLink={'SignIn'} emailHolder={"email"} passwordHolder={"password"} navlinkVal={"Don't have an account? "} navlink={"/userRegistration"} pre={'Admin'} fir={"Login"} sec={"Sign Up"}/>
  )
}