import React, { useState } from 'react';
import { Button, Checkbox, Form, Input, Select } from 'antd';
import { Placeholder } from 'react-bootstrap';
import { NavLink, useNavigate } from 'react-router-dom';
import axios from 'axios';
import Swal from 'sweetalert2'
import Link from '../../link';

const Login = ({ heading, navlink, navlinkVal, axiosLink, emailHolder, passwordHolder, pre, name, fir, sec }) => {
  const navigate = useNavigate();
  const onFinish = (values) => {
    axios.post(`${Link}${axiosLink}`,
      values
    ).then(function (res) {
      if (pre == 'Admin') {
        localStorage.setItem("Admin_ID", res.data.message._id)
        Swal.fire({
          title: "Good job!",
          text: "Successfully Login",
          icon: "success"
        });
        navigate('/home')
      }
      else if (pre == 'reg') {
        Swal.fire({
          title: "Good job!",
          text: "Successfully Login",
          icon: "success"
        });
        navigate('/')

      }

    }).catch((err) => {
      Swal.fire({
        icon: "error",
        title: "Oops...",
        text: `${err.message}`,
        footer: 'Something went wrong!'
      });
    })
  };
  const onFinishFailed = (errorInfo) => {

  };
  return (
    <div className="login">
      <div className='frame'>
        <h1 style={{ fontSize: "1.5rem", fontWeight: "600" }}>{heading}</h1>
        <hr style={{ margin: "1rem 1.2rem" }} />
        <Form
          name="basic"
          style={{
            justifyContent: "center",
            textAlign: "center"
          }}
          initialValues={{
            remember: true,
          }}

          onFinish={onFinish}
          onFinishFailed={onFinishFailed}
          autoComplete="off"
        >
          {
            name?
            <Form.Item
            name="name"

            rules={[
              {
                required: true,
                message: 'Please input your name!',
              },

            ]}
            style={{ margin: "2rem auto" }}
          >
            <Input placeholder={name} type='text' />
          </Form.Item>
          :null

          }
          

          <Form.Item
            name="email"

            rules={[
              {
                required: true,
                message: 'Please input your email!',
              },

            ]}
            style={{ margin: "2rem auto" }}
          >
            <Input placeholder={emailHolder} type='email' />
          </Form.Item>

          <Form.Item
            name="password"
            rules={[
              {
                required: true,
                message: 'Please input your password!',
              },
            ]}
            style={{ width: "21rem", margin: "2rem auto" }}
          >
            <Input.Password placeholder={passwordHolder} />
          </Form.Item>
          <Form.Item
          >
            <Button htmlType="submit">
              {fir}
            </Button>
          </Form.Item>
          <Form.Item
          >
            <a style={{ margin: "0 1rem", color: "#5C92F7" }}>{navlinkVal}</a>
            <NavLink to={navlink}><Button>
              {sec}
            </Button></NavLink>
          </Form.Item>
        </Form>
      </div>
    </div>
  )
};
export default Login;