
import Login from "../User Sign/Login"
export default function UserRegistration(){
    return(
        <div>
            <Login navlinkVal={"Already have an account? "} navlink={"/"} heading={"Sign Up"} name={"name"} axiosLink={'SignUp'} emailHolder={"email"} passwordHolder={"password"} pre={'reg'} fir={"Sign Up"} sec={"Login"}/>
        </div>
    )
}