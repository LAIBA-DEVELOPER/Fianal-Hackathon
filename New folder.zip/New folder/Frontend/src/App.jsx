import { useState } from 'react'
import './App.css'
import { BrowserRouter, Route, RouterProvider, Routes, createBrowserRouter, createRoutesFromElements } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import PageLayout from './Component/PageLayout';
import React from 'react';
import ReactDOM from 'react-dom';
import Login from './Component/User Sign/Log';
import UserRegistration from './Component/Registration/registration';
import Home from './Component/Home/home';

function App() {
  const router = createBrowserRouter(createRoutesFromElements(
    <Route element={<PageLayout />}>
      <Route path='/' element={<Login />} />
      <Route path='/userRegistration' element={<UserRegistration />} />
      <Route path='/Home' element={<Home />} />
    </Route >
  ))

  return (
    <RouterProvider router={router} />
  )
}

export default App
