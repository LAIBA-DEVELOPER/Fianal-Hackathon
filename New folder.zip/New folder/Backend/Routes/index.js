import express from 'express'
import SignUp from './signUp.js'
import SignIn from './SignIn.js'

const router = express.Router()

router.use('/SignUp', SignUp)
router.use('/SignIn', SignIn)

export default router